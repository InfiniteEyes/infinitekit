import os
import csv
import time
import logging
from datetime import datetime
import io

try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import letter
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    reportlab_available = True
except ImportError:
    logging.warning("ReportLab not available. PDF report generation will not work.")
    reportlab_available = False


def generate_pdf_report(scan, results, compliance_data=None):
    """
    Generate a PDF report for a scan
    
    Args:
        scan: Scan model instance
        results: List of scan results
        compliance_data: Optional dict with compliance report data (framework, report, detailed_results)
    
    Returns:
        str: Path to the generated PDF file
    """
    if not reportlab_available:
        logging.error("ReportLab library not available. Cannot generate PDF report.")
        raise ImportError("ReportLab library not available. Cannot generate PDF report.")
    
    # Create a temporary file to store the PDF
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = os.path.join(os.getcwd(), "reports")
    os.makedirs(output_dir, exist_ok=True)
    pdf_path = os.path.join(output_dir, f"scan_report_{scan.id}_{timestamp}.pdf")
    
    # Create the PDF document
    doc = SimpleDocTemplate(pdf_path, pagesize=letter)
    styles = getSampleStyleSheet()
    
    # Add custom styles
    styles.add(ParagraphStyle(
        name='Title',
        parent=styles['Heading1'],
        fontSize=20,
        spaceAfter=12
    ))
    styles.add(ParagraphStyle(
        name='Heading2',
        parent=styles['Heading2'],
        fontSize=16,
        spaceAfter=10
    ))
    styles.add(ParagraphStyle(
        name='Heading3',
        parent=styles['Heading3'],
        fontSize=14,
        spaceAfter=8
    ))
    styles.add(ParagraphStyle(
        name='Normal',
        parent=styles['Normal'],
        fontSize=10,
        spaceAfter=6
    ))
    
    # Group results by severity
    critical = []
    high = []
    medium = []
    low = []
    
    for result in results:
        if result.severity == 'critical':
            critical.append(result)
        elif result.severity == 'high':
            high.append(result)
        elif result.severity == 'medium':
            medium.append(result)
        elif result.severity == 'low':
            low.append(result)
    
    # Build the PDF content
    content = []
    
    # Title
    content.append(Paragraph(f"Security Scan Report", styles['Title']))
    content.append(Spacer(1, 0.25 * inch))
    
    # Scan Information
    scan_info_data = [
        ["Target", scan.target],
        ["Scan Type", scan.scan_type.capitalize()],
        ["Date", scan.created_at.strftime("%Y-%m-%d %H:%M:%S")],
        ["Status", scan.status.capitalize()],
    ]
    
    scan_info_table = Table(scan_info_data, colWidths=[2 * inch, 4 * inch])
    scan_info_table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
        ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ('PADDING', (0, 0), (-1, -1), 6),
    ]))
    
    content.append(scan_info_table)
    content.append(Spacer(1, 0.25 * inch))
    
    # Summary
    content.append(Paragraph("Executive Summary", styles['Heading2']))
    
    summary_text = f"""
    This report contains the results of a security scan performed on {scan.target}. 
    The scan identified a total of {len(results)} vulnerabilities/findings:
    - {len(critical)} Critical
    - {len(high)} High 
    - {len(medium)} Medium
    - {len(low)} Low
    """
    
    content.append(Paragraph(summary_text, styles['Normal']))
    content.append(Spacer(1, 0.25 * inch))
    
    # Detailed Results
    content.append(Paragraph("Detailed Findings", styles['Heading2']))
    
    # Function to add vulnerability section
    def add_vulnerability_section(title, vulnerabilities, severity_color):
        if not vulnerabilities:
            return
        
        content.append(Paragraph(title, styles['Heading3']))
        
        for vuln in vulnerabilities:
            vuln_title = f"{vuln.vulnerability_type.replace('_', ' ').title()}"
            content.append(Paragraph(vuln_title, styles['Heading3']))
            
            vuln_data = [
                ["Description", vuln.description],
                ["Details", vuln.details],
                ["Remediation", vuln.remediation if vuln.remediation else "No specific remediation available."],
            ]
            
            vuln_table = Table(vuln_data, colWidths=[1.5 * inch, 4.5 * inch])
            vuln_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (0, -1), severity_color),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('PADDING', (0, 0), (-1, -1), 6),
            ]))
            
            content.append(vuln_table)
            content.append(Spacer(1, 0.15 * inch))
    
    # Add vulnerability sections
    add_vulnerability_section("Critical Vulnerabilities", critical, colors.red)
    add_vulnerability_section("High Vulnerabilities", high, colors.orange)
    add_vulnerability_section("Medium Vulnerabilities", medium, colors.yellow)
    add_vulnerability_section("Low Vulnerabilities", low, colors.lightgreen)
    
    # Add compliance information if available
    if compliance_data:
        content.append(Paragraph("Compliance Report", styles['Heading2']))
        content.append(Spacer(1, 0.25 * inch))
        
        framework = compliance_data.get('framework')
        report = compliance_data.get('report')
        detailed_results = compliance_data.get('detailed_results')
        
        if framework and report and detailed_results:
            # Framework information
            content.append(Paragraph(f"Framework: {framework['name']} {framework['version']}", styles['Heading3']))
            content.append(Paragraph(framework['description'], styles['Normal']))
            content.append(Spacer(1, 0.15 * inch))
            
            # Compliance score
            content.append(Paragraph(f"Compliance Score: {report.compliance_score:.1f}%", styles['Heading3']))
            
            # Summary table
            summary = detailed_results.get('summary', {})
            summary_data = [
                ["Total Controls", str(summary.get('total_controls', 0))],
                ["Addressed Controls", str(summary.get('addressed_controls', 0))],
                ["Compliance Score", f"{report.compliance_score:.1f}%"]
            ]
            
            summary_table = Table(summary_data, colWidths=[2 * inch, 4 * inch])
            summary_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
                ('GRID', (0, 0), (-1, -1), 1, colors.black),
                ('PADDING', (0, 0), (-1, -1), 6),
            ]))
            
            content.append(summary_table)
            content.append(Spacer(1, 0.25 * inch))
            
            # Controls information
            content.append(Paragraph("Control Coverage Details", styles['Heading3']))
            
            for control in detailed_results.get('controls', []):
                # Determine if control is addressed
                is_addressed = len(control.get('vulnerabilities', [])) > 0
                status = "Addressed" if is_addressed else "Not Addressed"
                status_color = colors.green if is_addressed else colors.red
                
                content.append(Paragraph(f"{control['control_id']} - {control['name']}", styles['Heading3']))
                
                control_data = [
                    ["Description", control.get('description', 'No description available')],
                    ["Severity", control.get('severity', 'Unknown').capitalize()],
                    ["Status", status]
                ]
                
                control_table = Table(control_data, colWidths=[1.5 * inch, 4.5 * inch])
                control_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (0, -1), colors.lightgrey),
                    ('BACKGROUND', (1, 2), (1, 2), status_color),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black),
                    ('PADDING', (0, 0), (-1, -1), 6),
                ]))
                
                content.append(control_table)
                content.append(Spacer(1, 0.15 * inch))
                
                # Add mapped vulnerabilities if any
                if is_addressed:
                    content.append(Paragraph("Mapped Vulnerabilities:", styles['Normal']))
                    
                    for vuln in control.get('vulnerabilities', []):
                        vuln_data = [
                            ["Type", vuln.get('vulnerability_type', '').replace('_', ' ').title()],
                            ["Severity", vuln.get('severity', '').capitalize()],
                            ["Description", vuln.get('description', 'No description available')]
                        ]
                        
                        vuln_table = Table(vuln_data, colWidths=[1 * inch, 5 * inch])
                        vuln_table.setStyle(TableStyle([
                            ('GRID', (0, 0), (-1, -1), 1, colors.black),
                            ('PADDING', (0, 0), (-1, -1), 4),
                        ]))
                        
                        content.append(vuln_table)
                        content.append(Spacer(1, 0.1 * inch))
                
                content.append(Spacer(1, 0.15 * inch))
    
    # Build the PDF
    doc.build(content)
    
    logging.info(f"PDF report generated: {pdf_path}")
    return pdf_path


def generate_csv_report(scan, results):
    """
    Generate a CSV report for a scan
    
    Args:
        scan: Scan model instance
        results: List of scan results
    
    Returns:
        str: Path to the generated CSV file
    """
    # Create a directory for reports if it doesn't exist
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_dir = os.path.join(os.getcwd(), "reports")
    os.makedirs(output_dir, exist_ok=True)
    csv_path = os.path.join(output_dir, f"scan_report_{scan.id}_{timestamp}.csv")
    
    with open(csv_path, 'w', newline='') as csvfile:
        fieldnames = ['Vulnerability Type', 'Severity', 'Description', 'Details', 'Remediation']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        
        writer.writeheader()
        for result in results:
            writer.writerow({
                'Vulnerability Type': result.vulnerability_type.replace('_', ' ').title(),
                'Severity': result.severity.upper(),
                'Description': result.description,
                'Details': result.details,
                'Remediation': result.remediation if result.remediation else "No specific remediation available."
            })
    
    logging.info(f"CSV report generated: {csv_path}")
    return csv_path
