def get_remediation_steps(vulnerability_type):
    """
    Get remediation steps for a specific vulnerability type
    
    Args:
        vulnerability_type (str): Type of vulnerability
    
    Returns:
        str: Remediation steps
    """
    remediation_steps = {
        # Web vulnerabilities
        'server_info_disclosure': """
            Configure your web server to not disclose version information in HTTP headers.
            
            Apache:
            - Add 'ServerTokens Prod' and 'ServerSignature Off' to your Apache configuration.
            
            Nginx:
            - Add 'server_tokens off;' to your Nginx configuration.
            
            IIS:
            - Set the 'removeServerHeader' attribute to 'true' in the httpProtocol section of web.config.
        """,
        
        'missing_strict_transport_security': """
            Add the Strict-Transport-Security (HSTS) header to your web server configuration.
            
            Apache:
            - Add 'Header always set Strict-Transport-Security "max-age=31536000; includeSubDomains"' to your HTTPS virtual host configuration.
            
            Nginx:
            - Add 'add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;' to your server block.
            
            Express.js:
            - Use the helmet middleware: 'app.use(helmet.hsts({maxAge: 31536000, includeSubDomains: true}));'
        """,
        
        'missing_content_security_policy': """
            Implement a Content Security Policy (CSP) to prevent XSS attacks.
            
            Apache:
            - Add 'Header set Content-Security-Policy "default-src 'self';"' to your configuration.
            
            Nginx:
            - Add 'add_header Content-Security-Policy "default-src 'self';"' to your server block.
            
            HTML:
            - Add '<meta http-equiv="Content-Security-Policy" content="default-src 'self';">' to your HTML head.
            
            For a more comprehensive policy, consider allowing specific sources for scripts, styles, images, etc.
        """,
        
        'missing_x_content_type_options': """
            Add the X-Content-Type-Options header to prevent MIME type sniffing.
            
            Apache:
            - Add 'Header set X-Content-Type-Options "nosniff"' to your configuration.
            
            Nginx:
            - Add 'add_header X-Content-Type-Options "nosniff";' to your server block.
        """,
        
        'missing_x_frame_options': """
            Add the X-Frame-Options header to prevent clickjacking attacks.
            
            Apache:
            - Add 'Header set X-Frame-Options "SAMEORIGIN"' to your configuration.
            
            Nginx:
            - Add 'add_header X-Frame-Options "SAMEORIGIN";' to your server block.
        """,
        
        'missing_x_xss_protection': """
            Add the X-XSS-Protection header to enable browser XSS filters.
            
            Apache:
            - Add 'Header set X-XSS-Protection "1; mode=block"' to your configuration.
            
            Nginx:
            - Add 'add_header X-XSS-Protection "1; mode=block";' to your server block.
        """,
        
        'insecure_http': """
            Implement HTTPS for your website:
            
            1. Obtain an SSL certificate (Let's Encrypt provides free certificates).
            2. Configure your web server to use HTTPS.
            3. Implement redirects from HTTP to HTTPS.
            4. Consider using HSTS to enforce HTTPS connections.
            5. Update any hardcoded HTTP URLs in your application to use HTTPS.
        """,
        
        'potential_xss': """
            Protect against XSS (Cross-Site Scripting) attacks:
            
            1. Sanitize all user inputs before displaying them.
            2. Implement input validation with appropriate patterns and constraints.
            3. Use Content Security Policy (CSP) to limit what can be executed in the browser.
            4. Implement output encoding when rendering user-controlled data.
            5. Use framework-provided XSS protections (e.g., React's automatic escaping).
            6. Consider using a library like DOMPurify to sanitize HTML.
        """,
        
        'unsafe_javascript': """
            Fix unsafe JavaScript practices:
            
            1. Avoid using innerHTML, outerHTML, and document.write when possible.
            2. Use safer alternatives like textContent or innerText for text content.
            3. If you must use innerHTML, sanitize the input first with a library like DOMPurify.
            4. Use template elements and cloneNode instead of string manipulation for complex DOM structures.
            5. Implement Content Security Policy (CSP) to restrict script execution.
            6. Consider using a framework that handles DOM manipulation safely.
        """,
        
        'potential_sqli': """
            Protect against SQL Injection:
            
            1. Use parameterized queries or prepared statements for all database operations.
            2. Implement an ORM (Object-Relational Mapping) library that handles SQL escaping.
            3. Apply input validation on all user-controlled data before using it in queries.
            4. Use stored procedures when complex SQL is needed.
            5. Implement the principle of least privilege for database accounts.
            6. Use database connection pooling to minimize exposure.
            7. Consider using a web application firewall (WAF) as an additional layer of protection.
        """,
        
        'csrf_vulnerability': """
            Protect against CSRF (Cross-Site Request Forgery) attacks:
            
            1. Implement CSRF tokens in all forms and validate them on the server.
            2. Use the SameSite=Strict or SameSite=Lax attribute on cookies.
            3. Verify the Origin and Referer headers for API requests.
            4. Implement CORS policies to restrict cross-domain requests.
            5. Consider requiring re-authentication for sensitive operations.
            6. Use framework-provided CSRF protection (e.g., Django's csrf_protect).
            7. Apply the appropriate X-Frame-Options header to prevent clickjacking.
        """,
        
        'sensitive_file_exposure': """
            Protect sensitive files and directories:
            
            1. Remove unnecessary files from your web root directory.
            2. Configure your web server to deny access to configuration files and sensitive directories.
            3. Use a .gitignore file to avoid committing sensitive files to version control.
            4. Move sensitive files outside the web root when possible.
            5. Implement proper authentication for access to admin areas and config files.
            6. Disable directory listing in your web server configuration.
            7. Use appropriate file permissions to restrict access.
        """,
        
        'directory_listing': """
            Disable directory listing on your web server:
            
            Apache:
            - Add 'Options -Indexes' to your .htaccess file or server configuration.
            
            Nginx:
            - Remove 'autoindex on;' from your server block or add 'autoindex off;'
            
            IIS:
            - Set 'directoryBrowse' to 'false' in your web.config file.
            
            Additionally, ensure that all directories contain an index file (index.html, index.php, etc.).
        """,
        
        # Email vulnerabilities
        'invalid_email_format': """
            Implement proper email validation:
            
            1. Use a standards-compliant email validation library or regular expression.
            2. Consider implementing two-factor authentication for sensitive accounts.
            3. Implement email verification to confirm ownership.
            4. Use the 'email' input type in HTML forms for basic client-side validation.
        """,
        
        'disposable_email': """
            Handling disposable email addresses:
            
            1. Maintain a list of known disposable email domains and block them during registration.
            2. Implement email verification to confirm address ownership.
            3. Consider requiring phone verification for sensitive services.
            4. Monitor for suspicious activity from accounts using disposable emails.
        """,
        
        'missing_mx_records': """
            Fix missing MX records:
            
            1. Set up proper MX records for your domain through your DNS provider.
            2. Typical syntax: 'example.com. 3600 IN MX 10 mail.example.com.'
            3. Configure backup MX records with higher preference values.
            4. Verify your MX records using online tools like MXToolbox.
            5. Ensure your mail server is properly configured to receive emails.
        """,
        
        'missing_spf': """
            Implement SPF (Sender Policy Framework):
            
            1. Create an SPF record as a TXT record in your DNS.
            2. Basic example: 'v=spf1 mx a ip4:your_ip -all'
            3. Include all legitimate sending servers and services.
            4. Use '-all' for strict enforcement (reject non-matching senders).
            5. Test your SPF record using an SPF validation tool.
            6. Monitor your email delivery rates after implementation.
        """,
        
        'weak_spf_record': """
            Strengthen your SPF record:
            
            1. Change '+all' (allow all) to '-all' (fail unauthorized).
            2. Explicitly list all authorized sending IP addresses and services.
            3. Use 'include:' mechanisms for third-party services.
            4. Keep the record under 255 characters or use 'include:' for longer configurations.
            5. Test the record thoroughly before deployment.
            6. Monitor for legitimate emails being rejected after changes.
        """,
        
        'soft_fail_spf': """
            Improve your SPF soft fail configuration:
            
            1. Change '~all' (soft fail) to '-all' (hard fail) once you're confident all legitimate senders are included.
            2. Review and update the list of authorized senders regularly.
            3. Gradually transition from '~all' to '-all' while monitoring for rejected legitimate emails.
            4. Use SPF reporting and monitoring tools to identify missed legitimate senders.
        """,
        
        'missing_dmarc': """
            Implement DMARC (Domain-based Message Authentication, Reporting & Conformance):
            
            1. Create a DMARC record as a TXT record at _dmarc.yourdomain.com.
            2. Start with a monitoring policy: 'v=DMARC1; p=none; rua=mailto:reports@yourdomain.com'
            3. Gradually increase enforcement as you gain confidence:
               - p=quarantine (send to spam folder)
               - p=reject (block entirely)
            4. Analyze the received reports to identify legitimate senders.
            5. Add the 'pct' tag to apply policies gradually (e.g., pct=20 for 20% of messages).
            6. Implement subdomain policy with 'sp' if needed.
        """,
        
        'weak_dmarc_policy': """
            Strengthen your DMARC policy:
            
            1. Change 'p=none' to 'p=quarantine' or 'p=reject' for stronger enforcement.
            2. Implement a percentage tag (pct) to gradually increase enforcement.
            3. Add reporting addresses for aggregate (rua) and forensic (ruf) reports.
            4. Set a subdomain policy (sp) if it should differ from the main policy.
            5. Consider setting a strict alignment with 'adkim=s' and 'aspf=s'.
            6. Monitor reports to identify legitimate senders being affected.
        """,
        
        'header_inconsistency': """
            Fix email header inconsistencies:
            
            1. Ensure that 'From' header and 'Return-Path' addresses use the same domain.
            2. Properly configure your mail sending software or service.
            3. Implement SPF, DKIM, and DMARC to authenticate legitimate sending sources.
            4. Regularly audit your mail server configurations.
            5. Consider using a dedicated and well-configured email service provider.
        """,
        
        'missing_header': """
            Add missing email headers:
            
            1. Ensure your email sending system includes all standard headers:
               - Message-ID: A unique identifier for each email
               - Date: The date and time the message was sent
               - From: The sender's email address
               - To: The recipient's email address
            2. Configure your mail server or sending service to include these headers.
            3. Test your emails with header analysis tools to verify proper formatting.
        """,
        
        'suspicious_received_path': """
            Address suspicious email routing:
            
            1. Review your mail server configuration to ensure proper routing.
            2. Implement SPF, DKIM, and DMARC to authenticate legitimate sending paths.
            3. Consider using a trusted email gateway or filtering service.
            4. Monitor mail server logs for unusual routing patterns.
            5. Implement email filtering rules to block messages with suspicious routing.
        """,
        
        'authentication_failure': """
            Fix email authentication failures:
            
            1. Properly configure SPF by listing all authorized sending IP addresses.
            2. Implement DKIM signing for all outgoing emails with proper key management.
            3. Ensure your DMARC policy is properly configured and aligned with SPF and DKIM.
            4. Regularly rotate DKIM keys according to best practices.
            5. Monitor authentication failures using DMARC reports.
            6. Verify that all sending services and servers are properly authenticated.
        """,
        
        'phishing_subject': """
            Avoid phishing-like email subjects:
            
            1. Use clear, specific subject lines that avoid urgent language.
            2. Don't use ALL CAPS or excessive punctuation (!!!) in subject lines.
            3. Avoid subjects that create a false sense of urgency or threat.
            4. Train users to recognize phishing attempts.
            5. Implement sender authentication (SPF, DKIM, DMARC) to prove legitimacy.
            6. Consider preregistering message templates with email providers.
        """,
        
        'misleading_links': """
            Fix misleading links in emails:
            
            1. Ensure that link text matches the actual destination URL.
            2. Use descriptive link texts instead of bare URLs when appropriate.
            3. Avoid using URL shorteners in official communications.
            4. Implement email signing (DKIM) to prevent tampering.
            5. Consider using a link protection service that scans for malicious URLs.
            6. Educate users about checking link destinations before clicking.
        """,
        
        'dangerous_attachment': """
            Handle email attachments securely:
            
            1. Avoid sending executable files (.exe, .bat, etc.) through email.
            2. Use alternative file sharing methods for sensitive or executable content.
            3. Implement proper attachment scanning on mail servers.
            4. Consider using cloud storage links instead of direct attachments.
            5. Sign and encrypt attachments when appropriate.
            6. Implement clear policies on acceptable attachment types.
        """,
        
        # Infrastructure vulnerabilities
        'open_port_21': """
            Secure FTP service (port 21):
            
            1. If FTP is not needed, disable the service completely.
            2. Use SFTP (SSH File Transfer Protocol) or FTPS (FTP with SSL/TLS) instead of plain FTP.
            3. Implement strong authentication and access controls.
            4. Restrict FTP access to specific IP addresses if possible.
            5. Keep your FTP server software updated.
            6. Regularly audit FTP logs for unauthorized access attempts.
            7. Implement file integrity monitoring for transferred files.
        """,
        
        'open_port_22': """
            Secure SSH service (port 22):
            
            1. Use key-based authentication instead of passwords.
            2. Disable root login directly via SSH.
            3. Change the default SSH port to a non-standard port (though this is security by obscurity).
            4. Implement fail2ban to block repeated login attempts.
            5. Restrict SSH access to specific IP addresses if possible.
            6. Keep your SSH server updated with security patches.
            7. Implement proper user access controls and privileges.
            8. Consider using Multi-Factor Authentication (MFA) for SSH access.
        """,
        
        'open_port_23': """
            Telnet service (port 23) remediation:
            
            1. Disable Telnet service immediately - it transmits data in plaintext.
            2. Use SSH instead for remote administration.
            3. If Telnet must be used, restrict access to specific IP addresses.
            4. Implement a VPN if legacy systems require Telnet access.
            5. Monitor Telnet connections closely for unauthorized access.
            6. Consider using TCP wrappers for additional access control.
        """,
        
        'open_port_25': """
            Secure SMTP service (port 25):
            
            1. Implement authentication for mail relay.
            2. Use TLS encryption for SMTP communications.
            3. Consider blocking outbound port 25 except from authorized mail servers.
            4. Implement anti-spam measures like rate limiting.
            5. Keep your mail server software updated.
            6. Monitor SMTP logs for unauthorized relay attempts.
            7. Consider implementing SPF, DKIM, and DMARC to prevent email spoofing.
        """,
        
        'open_port_80': """
            Secure HTTP service (port 80):
            
            1. Redirect HTTP traffic to HTTPS using 301 redirects.
            2. Implement proper web server hardening.
            3. Keep your web server software updated.
            4. Remove unnecessary modules and features.
            5. Implement a Web Application Firewall (WAF).
            6. Use proper access controls for web content.
            7. Consider implementing HTTP security headers.
        """,
        
        'open_port_443': """
            Secure HTTPS service (port 443):
            
            1. Use strong SSL/TLS configurations (TLS 1.2+ with strong ciphers).
            2. Keep certificates up to date and properly configured.
            3. Implement HTTP security headers (HSTS, CSP, etc.).
            4. Regularly update your web server software.
            5. Consider using a Web Application Firewall (WAF).
            6. Implement proper access controls and authentication.
            7. Consider implementing certificate pinning for sensitive applications.
            8. Use automated certificate renewal to prevent expiration.
        """,
        
        'open_port_3389': """
            Secure RDP service (port 3389):
            
            1. If not needed, disable RDP service.
            2. Change the default RDP port.
            3. Implement Network Level Authentication (NLA).
            4. Use strong passwords and consider certificate-based authentication.
            5. Restrict RDP access to specific IP addresses.
            6. Implement account lockout policies to prevent brute force attacks.
            7. Keep your Windows system updated with security patches.
            8. Consider using Remote Desktop Gateway for enhanced security.
            9. Implement multi-factor authentication for RDP access.
        """,
        
        'vulnerable_service': """
            Secure vulnerable services:
            
            1. Update the service to the latest stable version.
            2. Apply any available security patches.
            3. If updates are not available, consider replacing with an alternative solution.
            4. Implement network-level protections (firewall rules, access controls).
            5. Consider using a reverse proxy or WAF to filter malicious requests.
            6. Regularly monitor for new vulnerabilities affecting the service.
            7. Implement the principle of least privilege for service accounts.
            8. Consider containerization to limit the blast radius of a compromise.
        """,
        
        'outdated_ssl_protocol': """
            Update SSL/TLS configuration:
            
            1. Disable SSLv2, SSLv3, TLSv1.0, and TLSv1.1 protocols.
            2. Enable only TLSv1.2 and TLSv1.3.
            3. Configure secure cipher suites and disable weak ciphers.
            4. Implement perfect forward secrecy with ECDHE or DHE key exchange.
            5. Regularly test your SSL/TLS configuration with tools like SSL Labs.
            6. Keep your SSL/TLS libraries and implementations updated.
            7. Consider implementing HSTS to force secure connections.
        """,
        
        'expired_ssl_cert': """
            Fix expired SSL certificate:
            
            1. Obtain and install a new SSL certificate immediately.
            2. Configure automated certificate renewal (e.g., using Let's Encrypt and certbot).
            3. Implement monitoring to alert before certificates expire.
            4. Consider using a certificate management solution for larger environments.
            5. Verify the new certificate is properly installed and working.
            6. Check certificate chain and intermediates are correctly configured.
        """,
        
        'self_signed_cert': """
            Replace self-signed certificate:
            
            1. Obtain a certificate from a trusted Certificate Authority (CA).
            2. Consider using Let's Encrypt for free trusted certificates.
            3. Properly install the new certificate with the complete trust chain.
            4. Configure automated renewal before expiration.
            5. If self-signed must be used (internal services), add it to trusted stores on client devices.
            6. Consider implementing a proper PKI for internal services.
        """
    }
    
    # Return the remediation steps or a default message
    return remediation_steps.get(vulnerability_type, "No specific remediation steps available for this vulnerability type.")
