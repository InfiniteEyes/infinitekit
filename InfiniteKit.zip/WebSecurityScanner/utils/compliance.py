"""
Utility functions for security framework compliance mapping and reporting
"""
from app import db
from models import (
    SecurityFramework, FrameworkControl, VulnerabilityMapping,
    ComplianceReport, ScanResult
)
import json


def seed_frameworks():
    """
    Seed the database with common security frameworks and their controls
    This should be run once during setup
    """
    # Check if we already have frameworks in the database
    if SecurityFramework.query.count() > 0:
        return "Frameworks already seeded"
    
    # OWASP Top 10 (2021)
    owasp = SecurityFramework(
        name="OWASP Top 10",
        version="2021",
        description="The Open Web Application Security Project Top 10 most critical web application security risks",
        website="https://owasp.org/Top10/"
    )
    db.session.add(owasp)
    db.session.flush()  # Get ID without committing
    
    # Add OWASP Top 10 controls
    owasp_controls = [
        FrameworkControl(
            framework_id=owasp.id,
            control_id="A01:2021", 
            name="Broken Access Control",
            description="Restrictions on what authenticated users are allowed to do are often not properly enforced.",
            severity="critical",
            category="Access Control"
        ),
        FrameworkControl(
            framework_id=owasp.id,
            control_id="A02:2021", 
            name="Cryptographic Failures",
            description="Failures related to cryptography which often lead to sensitive data exposure or system compromise.",
            severity="high",
            category="Cryptography"
        ),
        FrameworkControl(
            framework_id=owasp.id,
            control_id="A03:2021", 
            name="Injection",
            description="Injection flaws, such as SQL, NoSQL, OS, and LDAP injection occur when untrusted data is sent to an interpreter.",
            severity="critical",
            category="Injection"
        ),
        FrameworkControl(
            framework_id=owasp.id,
            control_id="A04:2021", 
            name="Insecure Design",
            description="Insecure design refers to design flaws in applications that can lead to widespread security issues.",
            severity="high",
            category="Design"
        ),
        FrameworkControl(
            framework_id=owasp.id,
            control_id="A05:2021", 
            name="Security Misconfiguration",
            description="Security misconfiguration is the most commonly seen issue, which is often a result of default or incomplete configurations.",
            severity="medium",
            category="Configuration"
        ),
        FrameworkControl(
            framework_id=owasp.id,
            control_id="A06:2021", 
            name="Vulnerable and Outdated Components",
            description="Components, such as libraries, frameworks, and other software modules, run with the same privileges as the application.",
            severity="medium",
            category="Dependencies"
        ),
        FrameworkControl(
            framework_id=owasp.id,
            control_id="A07:2021", 
            name="Identification and Authentication Failures",
            description="Authentication failures can allow attackers to compromise passwords, keys, or tokens.",
            severity="high",
            category="Authentication"
        ),
        FrameworkControl(
            framework_id=owasp.id,
            control_id="A08:2021", 
            name="Software and Data Integrity Failures",
            description="Software and data integrity failures relate to code and infrastructure that does not protect against integrity violations.",
            severity="high",
            category="Integrity"
        ),
        FrameworkControl(
            framework_id=owasp.id,
            control_id="A09:2021", 
            name="Security Logging and Monitoring Failures",
            description="This category is to help detect, escalate, and respond to active breaches.",
            severity="medium",
            category="Logging"
        ),
        FrameworkControl(
            framework_id=owasp.id,
            control_id="A10:2021", 
            name="Server-Side Request Forgery",
            description="SSRF flaws occur whenever a web application is fetching a remote resource without validating the user-supplied URL.",
            severity="medium",
            category="Request Validation"
        ),
    ]
    
    for control in owasp_controls:
        db.session.add(control)
    
    # NIST Cybersecurity Framework (CSF)
    nist = SecurityFramework(
        name="NIST Cybersecurity Framework",
        version="1.1",
        description="A voluntary framework consisting of standards, guidelines, and best practices to manage cybersecurity-related risk",
        website="https://www.nist.gov/cyberframework"
    )
    db.session.add(nist)
    db.session.flush()
    
    # Add NIST CSF controls (sampling the main functions)
    nist_controls = [
        FrameworkControl(
            framework_id=nist.id,
            control_id="ID", 
            name="Identify",
            description="Develop organizational understanding to manage cybersecurity risk to systems, people, assets, data, and capabilities.",
            severity="high",
            category="Risk Management"
        ),
        FrameworkControl(
            framework_id=nist.id,
            control_id="PR", 
            name="Protect",
            description="Develop and implement appropriate safeguards to ensure delivery of critical services.",
            severity="high",
            category="Protection"
        ),
        FrameworkControl(
            framework_id=nist.id,
            control_id="DE", 
            name="Detect",
            description="Develop and implement appropriate activities to identify the occurrence of a cybersecurity event.",
            severity="high",
            category="Detection"
        ),
        FrameworkControl(
            framework_id=nist.id,
            control_id="RS", 
            name="Respond",
            description="Develop and implement appropriate activities to take action regarding a detected cybersecurity incident.",
            severity="high",
            category="Response"
        ),
        FrameworkControl(
            framework_id=nist.id,
            control_id="RC", 
            name="Recover",
            description="Develop and implement appropriate activities to maintain plans for resilience and to restore any capabilities or services.",
            severity="high",
            category="Recovery"
        ),
    ]
    
    for control in nist_controls:
        db.session.add(control)
    
    # ISO 27001/27002
    iso = SecurityFramework(
        name="ISO/IEC 27001",
        version="2022",
        description="International standard for information security management systems (ISMS)",
        website="https://www.iso.org/isoiec-27001-information-security.html"
    )
    db.session.add(iso)
    db.session.flush()
    
    # Add ISO 27001/27002 controls (a selection of key controls)
    iso_controls = [
        FrameworkControl(
            framework_id=iso.id,
            control_id="5", 
            name="Organizational Controls",
            description="Controls related to information security roles, segregation of duties, and management directives.",
            severity="medium",
            category="Organization"
        ),
        FrameworkControl(
            framework_id=iso.id,
            control_id="6", 
            name="People Controls",
            description="Controls related to employment lifecycle and awareness training.",
            severity="medium",
            category="Personnel"
        ),
        FrameworkControl(
            framework_id=iso.id,
            control_id="8", 
            name="Asset Management",
            description="Controls related to responsibility for and classification of assets, and information handling.",
            severity="medium",
            category="Assets"
        ),
        FrameworkControl(
            framework_id=iso.id,
            control_id="9", 
            name="Access Control",
            description="Controls related to user access management, system and application access control.",
            severity="high",
            category="Access"
        ),
        FrameworkControl(
            framework_id=iso.id,
            control_id="12", 
            name="Operations Security",
            description="Controls related to operational procedures, protection from malware, and logging.",
            severity="high",
            category="Operations"
        ),
    ]
    
    for control in iso_controls:
        db.session.add(control)
    
    # Ensure all arrays have valid elements before creating mappings
    if len(owasp_controls) < 7 or len(nist_controls) < 2 or len(iso_controls) < 5:
        # If we don't have enough controls, just return without creating mappings
        # This prevents NULL control_id errors
        db.session.commit()
        return "Security frameworks partially seeded (without mappings)"
    
    # Add some basic vulnerability mappings
    mappings = [
        # OWASP Mappings
        VulnerabilityMapping(
            control_id=owasp_controls[0].id,  # A01 Broken Access Control
            vulnerability_type="authentication_bypass",
            mapping_confidence="high",
            notes="Authentication bypass directly relates to broken access control"
        ),
        VulnerabilityMapping(
            control_id=owasp_controls[0].id,  # A01 Broken Access Control
            vulnerability_type="authorization_bypass",
            mapping_confidence="high",
            notes="Authorization bypass directly relates to broken access control"
        ),
        VulnerabilityMapping(
            control_id=owasp_controls[2].id,  # A03 Injection
            vulnerability_type="sql_injection",
            mapping_confidence="high",
            notes="SQL injection is a classic example of injection vulnerabilities"
        ),
        VulnerabilityMapping(
            control_id=owasp_controls[2].id,  # A03 Injection
            vulnerability_type="command_injection",
            mapping_confidence="high",
            notes="Command injection is a form of injection vulnerability"
        ),
        VulnerabilityMapping(
            control_id=owasp_controls[2].id,  # A03 Injection
            vulnerability_type="xss",
            mapping_confidence="medium",
            notes="Cross-site scripting involves injection into web pages"
        ),
        VulnerabilityMapping(
            control_id=owasp_controls[4].id,  # A05 Security Misconfiguration
            vulnerability_type="server_misconfiguration",
            mapping_confidence="high",
            notes="Server misconfiguration directly relates to security misconfiguration"
        ),
        VulnerabilityMapping(
            control_id=owasp_controls[4].id,  # A05 Security Misconfiguration
            vulnerability_type="default_credentials",
            mapping_confidence="high",
            notes="Default credentials are a type of security misconfiguration"
        ),
        VulnerabilityMapping(
            control_id=owasp_controls[6].id,  # A07 Identification and Authentication Failures
            vulnerability_type="weak_password",
            mapping_confidence="high",
            notes="Weak passwords are a common authentication failure"
        ),
        
        # NIST CSF Mappings
        VulnerabilityMapping(
            control_id=nist_controls[1].id,  # PR Protect
            vulnerability_type="sql_injection",
            mapping_confidence="medium",
            notes="SQL injection vulnerabilities compromise the protect function"
        ),
        VulnerabilityMapping(
            control_id=nist_controls[1].id,  # PR Protect
            vulnerability_type="xss",
            mapping_confidence="medium",
            notes="XSS vulnerabilities compromise the protect function"
        ),
        VulnerabilityMapping(
            control_id=nist_controls[1].id,  # PR Protect
            vulnerability_type="weak_password",
            mapping_confidence="medium",
            notes="Weak passwords compromise the protect function"
        ),
        
        # ISO 27001 Mappings
        VulnerabilityMapping(
            control_id=iso_controls[3].id,  # 9 Access Control
            vulnerability_type="authentication_bypass",
            mapping_confidence="high",
            notes="Authentication bypass violates access control principles"
        ),
        VulnerabilityMapping(
            control_id=iso_controls[3].id,  # 9 Access Control
            vulnerability_type="authorization_bypass",
            mapping_confidence="high",
            notes="Authorization bypass violates access control principles"
        ),
        VulnerabilityMapping(
            control_id=iso_controls[4].id,  # 12 Operations Security
            vulnerability_type="server_misconfiguration",
            mapping_confidence="medium",
            notes="Server misconfiguration relates to operational security"
        ),
    ]
    
    for mapping in mappings:
        db.session.add(mapping)
    
    db.session.commit()
    return "Security frameworks seeded successfully"


def map_vulnerability_to_controls(vulnerability_type):
    """
    Find all framework controls that a specific vulnerability type maps to
    
    Args:
        vulnerability_type (str): Type of vulnerability
        
    Returns:
        dict: Dictionary of frameworks and their mapped controls
    """
    mappings = VulnerabilityMapping.query.filter_by(vulnerability_type=vulnerability_type).all()
    
    results = {}
    for mapping in mappings:
        control = mapping.control
        framework = control.framework
        
        if framework.name not in results:
            results[framework.name] = []
        
        results[framework.name].append({
            'control_id': control.control_id,
            'name': control.name,
            'confidence': mapping.mapping_confidence,
            'description': control.description,
            'severity': control.severity
        })
    
    return results


def generate_compliance_report(scan_id, framework_id):
    """
    Generate a compliance report for a scan against a specific framework
    
    Args:
        scan_id (int): ID of the scan
        framework_id (int): ID of the framework
        
    Returns:
        ComplianceReport: The generated compliance report
    """
    scan_results = ScanResult.query.filter_by(scan_id=scan_id).all()
    framework = SecurityFramework.query.get(framework_id)
    
    if not scan_results or not framework:
        return None
    
    # Get all controls for this framework
    all_controls = FrameworkControl.query.filter_by(framework_id=framework_id).all()
    total_controls = len(all_controls)
    
    # Map to track which controls are addressed
    controls_addressed = {control.id: False for control in all_controls}
    control_details = {control.id: {
        'control_id': control.control_id,
        'name': control.name,
        'description': control.description,
        'severity': control.severity,
        'vulnerabilities': []
    } for control in all_controls}
    
    # For each vulnerability in the scan results, find the mapped controls
    for result in scan_results:
        # Get mappings for this vulnerability type
        mappings = VulnerabilityMapping.query.filter_by(vulnerability_type=result.vulnerability_type).all()
        
        for mapping in mappings:
            if mapping.control_id in controls_addressed:
                controls_addressed[mapping.control_id] = True
                control_details[mapping.control_id]['vulnerabilities'].append({
                    'vulnerability_type': result.vulnerability_type,
                    'severity': result.severity,
                    'description': result.description,
                    'confidence': mapping.mapping_confidence
                })
    
    # Calculate compliance score
    addressed_count = sum(1 for v in controls_addressed.values() if v)
    compliance_score = (addressed_count / total_controls) * 100 if total_controls > 0 else 0
    
    # Create detailed report
    detailed_report = {
        'framework': {
            'name': framework.name,
            'version': framework.version,
            'description': framework.description
        },
        'summary': {
            'total_controls': total_controls,
            'addressed_controls': addressed_count,
            'compliance_score': compliance_score
        },
        'controls': list(control_details.values())
    }
    
    # Save the report
    new_report = ComplianceReport(
        scan_id=scan_id,
        framework_id=framework_id,
        compliance_score=compliance_score,
        details=json.dumps(detailed_report)
    )
    
    db.session.add(new_report)
    db.session.commit()
    
    return new_report


def get_all_frameworks():
    """
    Get all available security frameworks
    
    Returns:
        list: List of SecurityFramework objects
    """
    return SecurityFramework.query.all()


def get_framework_details(framework_id):
    """
    Get detailed information about a security framework including its controls
    
    Args:
        framework_id (int): ID of the framework
        
    Returns:
        dict: Dictionary containing framework details and controls
    """
    framework = SecurityFramework.query.get(framework_id)
    if not framework:
        return None
    
    controls = FrameworkControl.query.filter_by(framework_id=framework_id).all()
    
    result = {
        'id': framework.id,
        'name': framework.name,
        'version': framework.version,
        'description': framework.description,
        'website': framework.website,
        'controls': []
    }
    
    for control in controls:
        result['controls'].append({
            'id': control.id,
            'control_id': control.control_id,
            'name': control.name,
            'description': control.description,
            'severity': control.severity,
            'category': control.category
        })
    
    return result