"""
Utility functions for security framework compliance mapping and reporting
"""
from app import db
from models import (
    SecurityFramework, FrameworkControl, VulnerabilityMapping,
    ComplianceReport, ScanResult
)
import json


def seed_frameworks():
    """
    Seed the database with common security frameworks and their controls
    This should be run once during setup
    """
    # Check if we already have frameworks in the database
    if SecurityFramework.query.count() > 0:
        return "Frameworks already seeded"
    
    try:
        # OWASP Top 10 (2021)
        owasp = SecurityFramework(
            name="OWASP Top 10",
            version="2021",
            description="The Open Web Application Security Project Top 10 most critical web application security risks",
            website="https://owasp.org/Top10/"
        )
        db.session.add(owasp)
        db.session.commit()
        
        # Add one basic control
        control = FrameworkControl(
            framework_id=owasp.id,
            control_id="A01:2021", 
            name="Broken Access Control",
            description="Restrictions on what authenticated users are allowed to do are often not properly enforced.",
            severity="critical",
            category="Access Control"
        )
        db.session.add(control)
        db.session.commit()
        
        # Basic mapping only - simplified approach
        return "Security frameworks successfully initialized with minimal controls."
        
    except Exception as e:
        db.session.rollback()
        return f"Error seeding frameworks: {str(e)}"


def map_vulnerability_to_controls(vulnerability_type):
    """
    Find all framework controls that a specific vulnerability type maps to
    
    Args:
        vulnerability_type (str): Type of vulnerability
        
    Returns:
        dict: Dictionary of frameworks and their mapped controls
    """
    mappings = VulnerabilityMapping.query.filter_by(vulnerability_type=vulnerability_type).all()
    
    results = {}
    for mapping in mappings:
        control = mapping.control
        framework = control.framework
        
        if framework.name not in results:
            results[framework.name] = []
        
        results[framework.name].append({
            'control_id': control.control_id,
            'name': control.name,
            'confidence': mapping.mapping_confidence,
            'description': control.description,
            'severity': control.severity
        })
    
    return results


def generate_compliance_report(scan_id, framework_id):
    """
    Generate a compliance report for a scan against a specific framework
    
    Args:
        scan_id (int): ID of the scan
        framework_id (int): ID of the framework
        
    Returns:
        ComplianceReport: The generated compliance report
    """
    # Simple placeholder implementation
    scan_results = ScanResult.query.filter_by(scan_id=scan_id).all()
    framework = SecurityFramework.query.get(framework_id)
    
    if not scan_results or not framework:
        return None
    
    # Create a simple report
    detailed_report = {
        'framework': {
            'name': framework.name,
            'version': framework.version,
            'description': framework.description
        },
        'summary': {
            'total_controls': 1,
            'addressed_controls': 0,
            'compliance_score': 0
        },
        'controls': []
    }
    
    # Save the report
    new_report = ComplianceReport(
        scan_id=scan_id,
        framework_id=framework_id,
        compliance_score=0,
        details=json.dumps(detailed_report)
    )
    
    db.session.add(new_report)
    db.session.commit()
    
    return new_report


def get_all_frameworks():
    """
    Get all available security frameworks
    
    Returns:
        list: List of SecurityFramework objects
    """
    return SecurityFramework.query.all()


def get_framework_details(framework_id):
    """
    Get detailed information about a security framework including its controls
    
    Args:
        framework_id (int): ID of the framework
        
    Returns:
        dict: Dictionary containing framework details and controls
    """
    framework = SecurityFramework.query.get(framework_id)
    if not framework:
        return None
    
    controls = FrameworkControl.query.filter_by(framework_id=framework_id).all()
    
    result = {
        'id': framework.id,
        'name': framework.name,
        'version': framework.version,
        'description': framework.description,
        'website': framework.website,
        'controls': []
    }
    
    for control in controls:
        result['controls'].append({
            'id': control.id,
            'control_id': control.control_id,
            'name': control.name,
            'description': control.description,
            'severity': control.severity,
            'category': control.category
        })
    
    return result